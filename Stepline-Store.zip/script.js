gsap.registerPlugin(ScrollTrigger);

gsap.utils.toArray('.reveal').forEach(el=>{
  if(el.closest('.hero')) return;
  gsap.to(el,{opacity:1,y:0,duration:.9,scrollTrigger:{trigger:el,start:'top 88%'}});
});

if(document.querySelector('.hero')){
  gsap.timeline({delay:.1})
    .from('.hero h1',{opacity:0,y:40,duration:.9,ease:'power3.out'})
    .from('.hero-meta',{opacity:0,y:20,duration:.7},'-=.4')
    .from('.ticker',{opacity:0,duration:.6},'-=.2');

  const track = document.getElementById('tickerTrack');
  if(track){
    track.innerHTML += track.innerHTML;
    gsap.to(track,{xPercent:-50,duration:14,repeat:-1,ease:'none'});
  }
}

if(document.querySelector('.page-head')){
  gsap.from('.page-head .crumb',{opacity:0,y:10,duration:.5});
  gsap.from('.page-head h1',{opacity:0,y:20,duration:.7,delay:.1});
}

gsap.utils.toArray('.card').forEach((card,i)=>{
  gsap.fromTo(card,{opacity:0,y:30},{opacity:1,y:0,duration:.6,delay:(i%3)*0.08,scrollTrigger:{trigger:card,start:'top 92%'}});
});

document.querySelectorAll('.filters span').forEach(f=>{
  f.addEventListener('click',()=>{
    document.querySelectorAll('.filters span').forEach(s=>s.classList.remove('active'));
    f.classList.add('active');
  });
});

function updateCartPill(delta){
  const pill = document.querySelector('.cart-pill');
  if(!pill) return;
  let count = parseInt(pill.textContent.match(/\d+/)[0]) + delta;
  if(count<0) count=0;
  pill.innerHTML = `<span class="cart-dot"></span> السلة (${count})`;
}

document.querySelectorAll('.add, .add-big').forEach(btn=>{
  btn.addEventListener('click',(e)=>{
    e.stopPropagation();
    gsap.fromTo(btn,{scale:1},{scale:1.08,duration:.15,yoyo:true,repeat:1});
    updateCartPill(1);
  });
});

// size selector (product.html)
document.querySelectorAll('.size-grid span').forEach(s=>{
  s.addEventListener('click',()=>{
    document.querySelectorAll('.size-grid span').forEach(x=>x.classList.remove('selected'));
    s.classList.add('selected');
  });
});

// thumbnail swap (product.html)
document.querySelectorAll('.thumb').forEach(t=>{
  t.addEventListener('click',()=>{
    const main = document.querySelector('.product-shot .shoe');
    if(main) gsap.fromTo(main,{scale:.7,opacity:0},{scale:1,opacity:1,duration:.4});
  });
});

// cart quantity controls (cart.html)
document.querySelectorAll('.qty-box').forEach(box=>{
  const span = box.querySelector('span');
  box.querySelectorAll('button')[0]?.addEventListener('click',()=>{
    let v = parseInt(span.textContent); if(v>1) span.textContent = v-1;
  });
  box.querySelectorAll('button')[1]?.addEventListener('click',()=>{
    let v = parseInt(span.textContent); span.textContent = v+1;
  });
});

// auth forms (login.html / signup.html) — frontend demo only
const authForm = document.getElementById('authForm');
if(authForm){
  authForm.addEventListener('submit',(e)=>{
    e.preventDefault();
    const btn = authForm.querySelector('.submit-btn');
    btn.textContent='جاري التحقق...';
    setTimeout(()=>{btn.textContent='تم ✓ (واجهة تجريبية)';},800);
  });
}

const burger = document.querySelector('.burger');
if(burger){
  burger.addEventListener('click',()=>{
    const ul = document.querySelector('nav ul');
    ul.style.display = ul.style.display==='flex' ? 'none' : 'flex';
    ul.style.position='absolute';ul.style.top='68px';ul.style.right='6%';
    ul.style.flexDirection='column';ul.style.background='#dedad2';ul.style.padding='18px 26px';
    ul.style.border='2px solid #17150f';ul.style.borderRadius='10px';ul.style.gap='14px';
  });
}
